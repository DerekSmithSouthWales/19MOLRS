The clique partitions for a t-subgraph (t=19, k-1=56) are contained in the file:
 
19Clique_partitions_k-1=56_branch_leaf.txt

The corresponding set of 19 decreasing mutually orthogonal Latin rectangles are contained in the file:

19_decreasing_Latin-rectangles_k-1=56.txt

The construction of the decreasing mutually orthogonal Latin rectangles can be found in the paper:
Moore graphs and decreasing sets of
mutually orthogonal Latin rectangles
by Derek H. Smith and Roberto Montemanni

Details of the construction of a t-subgraph with t=20 can be found in the paper:
Potential Subgraphs of the Missing Moore Graph
by Derek H. Smith and Roberto Montemanni